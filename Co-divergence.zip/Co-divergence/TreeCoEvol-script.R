setwd("path")
library(ape)

#########################################
##  run it once 
#########################################
###sim-cosp function##
sim_cosp<-function (d_h, d_p, rel, nsample) 
{
  if (is.data.frame(d_h)) 
    d_h = as.matrix(d_h)
  if (is.data.frame(d_p)) 
    d_p = as.matrix(d_p)
  if (is.matrix(d_h) == FALSE) 
    stop(paste(sQuote("d_h"), "is not a matrix"))
  if (is.matrix(d_p) == FALSE) 
    stop(paste(sQuote("d_p"), "is not a matrix"))
  if (dim(rel)[1] != dim(d_p)[1] || dim(rel)[2] != dim(d_h)) 
    stop(paste(sQuote("rel"), "has not correct dimensions"))
  if (sum(rel != 0) + sum(rel != 1) != dim(rel)[1] * dim(rel)[2]) 
    stop(paste("Entries in", sQuote("rel"), "not correct. Please check input."))
  if (is.numeric(nsample) == FALSE) 
    stop(paste(sQuote("nsample"), "is not numeric"))
  m = sum(rel)
  rel_1 = matrix(nrow = m, ncol = 2)
  s = 1
  while (s <= m) {
    for (i in 1:dim(rel)[1]) {
      for (j in 1:dim(rel)[2]) {
        if (rel[i, j] == 1) {
          rel_1[s, 1] = j
          rel_1[s, 2] = i
          s = s + 1
        }
      }
    }
  }
  getdist = function(v, matrix, row) {
    vec = vector(length = choose(m, 2))
    o.r = order(row)
    a = 1
    for (i in 1:(m - 1)) {
      k = o.r[v[i]]
      for (j in (i + 1):m) {
        t = o.r[v[j]]
        vec[a] = matrix[k, t]
        a = a + 1
      }
    }
    return(vec)
  }
  x = getdist(rel_1[, 1], d_h, as.integer(rownames(d_h)))
  y = getdist(rel_1[, 2], d_p, as.integer(rownames(d_p)))
  r_real = cor(x, y)
  m.h = dim(d_h)[1]
  m.p = dim(d_p)[1]
  tail=0
  for (i in 1:nsample) {
    simlabel.h = sample(1:m.h)
    simlabel.p = sample(1:m.p)
    x_s = getdist(rel_1[, 1], d_h, simlabel.h)
    y_s = getdist(rel_1[, 2], d_p, simlabel.p)
    r_s = cor(x_s, y_s)
    if (r_s >= r_real) tail=tail+1
  }
  p = (tail+1)/(nsample+1)
  #
  #
  return(list(p=p,tail=tail,correlation=r_real))
}

#########################################################

#read in trees

tree_host=read.tree("Host.treefile")
tree_par=read.tree("virus.treefile")
print(tree_host)
print(tree_par)

#calculate patristic distances

dist_host=cophenetic(tree_host)
dist_par=cophenetic(tree_par)
rownames(dist_host)<-seq(1,32)
colnames(dist_host)<-seq(1,32)
rownames(dist_par)<-seq(1,5)
colnames(dist_par)<-seq(1,5)

print(dist_host)
print(dist_par)

#read in interactions
relation=read.table("relation-virus.txt")
relation2<-t(relation)
dim(relation2)
print(relation)



#set.seed(1) #allows to reproduce the simulation result
p=sim_cosp(dist_host,dist_par,relation,100)
p 

#set.seed(1) #allows to reproduce the simulation result
p=sim_cosp(dist_host,dist_par,relation,9999)
p


